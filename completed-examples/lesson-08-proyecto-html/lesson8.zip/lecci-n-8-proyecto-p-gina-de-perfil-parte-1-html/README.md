# Lección 8: Proyecto, página de perfil (parte 1: HTML)

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Yngrid-Ruiz/pen/01a1dbbd-4714-7772-89fd-1aa66bc80528](https://codepen.io/editor/Yngrid-Ruiz/pen/01a1dbbd-4714-7772-89fd-1aa66bc80528).

