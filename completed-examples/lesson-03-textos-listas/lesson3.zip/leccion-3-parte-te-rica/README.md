# Leccion 3: Parte Teórica

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/TooGe-Potier/pen/01a1dbcf-348b-7c57-b8c0-1281318cf936](https://codepen.io/editor/TooGe-Potier/pen/01a1dbcf-348b-7c57-b8c0-1281318cf936).

