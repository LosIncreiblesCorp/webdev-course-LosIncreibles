# Lección 7: Centrar y organizar el contenido

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/Yngrid-Ruiz/pen/01a1dbb6-d05d-76b0-bb12-68b9a698d64e](https://codepen.io/editor/Yngrid-Ruiz/pen/01a1dbb6-d05d-76b0-bb12-68b9a698d64e).

