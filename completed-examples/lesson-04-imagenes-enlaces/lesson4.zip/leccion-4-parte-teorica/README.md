# Leccion 4: Parte Teorica

A Pen created on CodePen.

Original URL: [https://codepen.io/editor/TooGe-Potier/pen/01a1dbd8-291a-71da-889a-d2c740d528f3](https://codepen.io/editor/TooGe-Potier/pen/01a1dbd8-291a-71da-889a-d2c740d528f3).

